
////// the navigation buttons and moving from page A to page B

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("log-out").addEventListener("click", function() {
        window.location.href = "../Views/Home.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("register-now-button").addEventListener("click", function() {
        window.location.href = "../Views/Register.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("signIn-now-button").addEventListener("click", function() {
        window.location.href = "../Views/SignIn.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("aboutUs-now-button").addEventListener("click", function() {
        window.location.href = "../Views/AboutUs.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("aboutUs-now-button").addEventListener("click", function() {
        window.location.href = "../Views/AboutUs.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("orSignUp-now-button").addEventListener("click", function() {
        window.location.href = "../Views/AboutUs.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
     document.getElementById("my-profile").addEventListener("click", function() {
        window.location.href = "../Views/MyProfile.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
     document.getElementById("BookNewLesson").addEventListener("click", function() {
        window.location.href = "../Views/BookLesson.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("orSignUp-now-button").addEventListener("click", function() {
        window.location.href = "../Views/AboutUs.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("ViewLessonTypes").addEventListener("click", function() {
        window.location.href = "../Views/LessonTypes.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("ViewMyBookings").addEventListener("click", function() {
        window.location.href = "../Views/MyBookings.html";
    });
});
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("EditMyInformation").addEventListener("click", function() {
        window.location.href = "../Views/EditInfo.html";
    });
});