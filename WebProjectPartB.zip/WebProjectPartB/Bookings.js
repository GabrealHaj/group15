

const myBookings = [];
class lesson {
    constructor(type, date, time) {
        this.type = type;
        this.date = new Date(date);
        this.time = time;
    }

    // Getters and setters
    getFullName() {
        return `${this.time} ${this.time}`
    }
    getFirstName() {
        return `${this.date} `
    }
    getLastName() {
        return `${this.type}`

    }
}

/////////////////// some objects fot checking if the system woks well ////////////////////
const lesson1 = new lesson('Pilates','23/02/2024','14:00')
const lesson2 = new lesson('HIIT','29/02/2024','20:00')
const lesson3 = new lesson('Yoga','27/02/2024','9:00')
myBookings.push(lesson1, lesson2, lesson3);
function validateFutureDate(date) {    // check if the date hasn't passed
    const inputDate = new Date(date);
    const currentDate = new Date();
    return inputDate >= currentDate;
}

function validateTime(time) {
    // Parse the entered time string into hours and minutes
    const [hours, minutes] = time.split(':').map(Number);
    // Check if the time is within the required range (between 09:00 and 20:00)
    return (hours >= 9 && hours <= 20) && (minutes===0); // Assuming lessons start at 09:00 and end at 19:59
}

function newBooking(event){
        event.preventDefault();

    //Input data
      const lessonType = document.getElementById("lesson-type").value;
      const lessonDate = document.getElementById("lesson-date").value;
      const lessonTime = document.getElementById("lesson-time").value;


      //check the date
    if (!validateFutureDate(lessonDate)) {
    alert("Choose another date, please.")
    }
    else if (!validateTime(lessonTime)) {
        alert("choose a rounded hours only between 9:00 and 20:00,please.")
    }
    else{          //if the date is valid and the customer picks a valid time create the new lesson

        let lesson = {
            type : lessonType , date : lessonDate , time : lessonTime
        };
        myBookings.push(lesson)
        console.log("A new lesson is booked:", lesson);

          // change button color for 3 second
        event.target.style.background = 'green'
        event.target.innerText = 'Succeeded'
        setTimeout(function() {
            event.target.style.background = '';
            event.target.innerText = 'Book A Lesson';
            }, 3000);

        // Clear the form
        document.getElementById("bookingForm").reset();
        console.log(myBookings)
    }
}


// Add event listener to form submission
document.getElementById("book-lesson-button").addEventListener("click", newBooking);

        window.console.log(myBookings)
//allCustomers.pop()




//////Cancel booking function//////
  function cancelBooking(button) {   //cancel bookings function
     console.log("Cancel button clicked");
    const row = button.parentNode.parentNode; // Get the parent row of the clicked button
      alert("You cancelled booking number " + (+row.rowIndex ) + " !");
        const table = row.parentNode; // Get the parent table of the row
        table.deleteRow(row.rowIndex);

  }

//////updating the tables according to the date//////
function moveCompletedLessons() {
    const futureTable = document.getElementById("My-Future-Bookings");
    const completedTable = document.getElementById("My-Completed-Bookings");
    const currentDate = new Date();

    // Iterate through each row in the future table
    for (let i = 1; i < futureTable.rows.length; i++) {
        const row = futureTable.rows[i];
    const bookingDate = row.cells[2].textContent;
    const bookingDateSplit = bookingDate.split('/'); // Parse the date string to a Date object
    const bookingD = new Date(parseInt(bookingDateSplit[2]), parseInt(bookingDateSplit[1]) - 1, parseInt(bookingDateSplit[0]));
      if (bookingD < currentDate) {// Check if the lesson date has passed
            row.deleteCell(row.cells.length - 1);
            completedTable.appendChild(row);            // Move the row to the completed table

            i--; // future table length is one index shorter
        }
    }
}

