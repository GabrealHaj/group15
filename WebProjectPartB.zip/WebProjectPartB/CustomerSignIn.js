
/// Sign In event ////


///this is a temporary code to check the functionality of our sign in page

/// added an event listener for the submit sign in button
/// added a  function te keep user signed in
///check email and password and then go to MyProfile page



function validSignIn(email,password,allCustomers) {
            for (const customer of allCustomers) {
                    if (customer.email === email ) {
                        if (customer.password)
                        return true;
                    }
            }
                return false;
        }
function signIn() {

    const emailInput = document.getElementById('signInEmail').value;
    const passwordInput = document.getElementById('signInPassword').value;
        console.log(emailInput)

        if ( !emailInput || !passwordInput) {
            alert('Email & password are required!');
            return;
        } else if (validSignIn(emailInput,passwordInput,allCustomers)){
            window.location.href = "/Views/MyProfile.html"
        }
        else {
            alert('Email or password are wrong ! try again !');
        }

}

document.getElementById("sign-in-button").addEventListener("click", signIn );



// //this code will work only after the backend developing and connecting to the server

//         try {
//             const response = await fetch('/api/signIn', {
//                 method: 'POST',
//                 headers: { 'Content-Type': 'application/json' },
//                 body: JSON.stringify({ email, password }),
//             });
//
//             if (!response.ok) {
//                 throw new Error('Server error occurred');
//             }
//
//             const data = await response.json();
//
//             if (data.length > 0) {
//                 sessionStorage.setItem('LOGGED_IN_USER', JSON.stringify(data[0]));
//                 window.location.href = '/Views/MyProfile.html';
//             } else {
//                 alert('No user was found for the given email & password!');
//             }
//         } catch (error) {
//             alert('A server error occurred');
//             console.error(error);
//         }